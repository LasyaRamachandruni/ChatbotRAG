# SJSU King Library Org Chart

Staff, faculty, and roles at SJSU Library.